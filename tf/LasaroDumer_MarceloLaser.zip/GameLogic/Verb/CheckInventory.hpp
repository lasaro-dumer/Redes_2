#ifndef checkIH
#define checkIH
#include "../Noun/Element.hpp"
#include "../Game.hpp"
#include "../response.hpp"
#include <string>
#include <list>
#include <vector>

dungeonResponse* CheckInventory(Player* sender);

#endif
